Kyiv.city — Android-проєкт

Цей архів містить Android Studio проєкт із грою Kyiv.city, вбудованою
в застосунок. Гра працює локально, без підключення до інтернету.

Як зібрати APK:
1. Встановіть Android Studio на комп'ютер.
2. Відкрийте папку KyivCity-Android через File → Open.
3. Дочекайтеся завершення Gradle Sync та встановлення Android SDK 35,
   якщо Android Studio попросить.
4. Оберіть Build → Build Bundle(s) / APK(s) → Build APK(s).
5. APK буде створено в app/build/outputs/apk/debug/app-debug.apk.

Як встановити на планшет:
1. Перенесіть app-debug.apk на Android-планшет.
2. Відкрийте APK та підтвердьте встановлення.
   Android може попросити дозволити встановлення з цього джерела.
3. Запустіть Kyiv.city з екрана програм.

Примітка: цей архів є вихідним Android Studio проєктом, а не готовим APK.
Для збирання потрібні Android Studio та Android SDK.


Збірка через GitHub Actions без Android Studio:
1. Створіть порожній репозиторій на GitHub.
2. Завантажте в нього цей архів під назвою KyivCity-Android-Project.zip.
3. Додайте файл .github/workflows/build.yml з вмістом файлу KyivCity-build.yml.
4. Відкрийте вкладку Actions, оберіть "Build Kyiv.city APK" і натисніть Run workflow.
5. Після завершення відкрийте запуск workflow і завантажте артефакт Kyiv-city-APK.
6. Розпакуйте артефакт і відкрийте app-debug.apk на телефоні.
